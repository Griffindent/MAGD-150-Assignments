var angle = 0.0;
var offset = 60;
var scalar = 50;
var speed = 100.00;
var x,y;
var xspeed;
function setup() {
  createCanvas(800,600);
  background(255, 226, 141);
}

function draw() {
  fill(171, 117, 2);
  rect(125,150,350,350);
  fill(225);
  rect(150,175,300,300);
  line(125,100,300,150);
  line(475,100,300,150);
  fill(0);
  rect(550,100,150,450);
  fill(255,0,0);
  ellipse(625,125,20,20);
  fill(255);
  text("Power",605,150);
  fill(0, 255, 242);
  rect(575,250,100,100);
  fill(255);
  text("GO CRAZY",595,365);
  
  if(mouseIsPressed){
    if(mouseX>575 && mouseX<575+100 && mouseY>250 && mouseY<250+100){
      var x = offset +cos(angle)*scalar;
      var y = offset +sin(angle)*scalar;
      ellipse(x+245,y+245,40,40)
      angle += speed;
    }
  if(mouseIsPressed) {
    if(mouseX>625 && mouseX<625+25 && mouseY>125 && mouseY<125+25) { //click is slightly down and to left of button
      fill(166,5,5);
      ellipse(625,125,20,20);
      fill(252, 186, 3);
      rect(150,175,300,300);
    }
  }
  }
}